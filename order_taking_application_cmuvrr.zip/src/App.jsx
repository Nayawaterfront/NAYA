import React, { useState } from 'react';
    import UnitDetails from './components/UnitDetails';
    import BookingInfo from './components/BookingInfo';
    import ImageGallery from './components/ImageGallery';
    import Payment from './components/Payment';
    import SocialLinks from './components/SocialLinks';
    import Chatbot from './components/Chatbot';
    import Directions from './components/Directions';
    import EmailCollection from './components/EmailCollection';
    import PromoCode from './components/PromoCode';
    import VideoGallery from './components/VideoGallery';

    const App = () => {
      const unitData = {
        title: 'Naya Waterfront Homestay - Luxurious Beach Getaway',
        description: 'Indulge in a luxurious escape at Naya Waterfront, a stunning 4-bedroom homestay in Port Dickson. Experience the perfect blend of comfort and elegance, just moments from the beach.',
        price: 750,
        originalPrice: 1200,
        amenities: ['Free WiFi', 'Gourmet Kitchen', 'Ocean View Balcony', 'Infinity Pool Access', 'Karaoke System'],
        airbnbLink: 'https://www.airbnb.com/rooms/1150508266431293040?adults=11&search_mode=regular_search&check_in=2025-03-01&check_out=2025-03-06&children=0&infants=0&pets=0&source_impression_id=p3_1739999790_P3TZ-AW5Kii-970n&previous_page_section_name=1000&federated_search_id=127da13f-413e-4bf1-a031-4095a85ee613',
        address: 'No 1, Jalan Impian Putra 10, Taman Impian Putra, 71000 Port Dickson, Negeri Sembilan',
      };

      const images = [
        '/image1.jpg',
        '/image2.jpg',
        '/image3.jpg',
      ];

      const socialLinks = {
        instagram: 'https://www.instagram.com/nayawaterfront?igsh=eWprc295MWNwb2Jh',
        tiktok: 'https://www.tiktok.com/@naya.waterfront.p?_t=ZS-8u3ZFOGepXt&_r=1',
        facebook: 'https://www.facebook.com/permalink.php/?story_fbid=122095538294546897&id=61566406915691',
      };

      const [promoCode, setPromoCode] = useState('BEACH20');
      const [validDays, setValidDays] = useState(['Saturday', 'Sunday']);

      const youtubeVideoUrl = 'https://www.youtube.com/embed/PInn22VG6C0';
      const tiktokVideoUrl = 'https://www.tiktok.com/embed/7423029510485970183';

      return (
        <div className="app-container">
          <h1>{unitData.title}</h1>
          <ImageGallery images={images} />
          <VideoGallery videoUrl={youtubeVideoUrl} videoSource="youtube" />
          <VideoGallery videoUrl={tiktokVideoUrl} videoSource="tiktok" />
          <UnitDetails unitData={unitData} />
          <BookingInfo price={unitData.price} originalPrice={unitData.originalPrice} airbnbLink={unitData.airbnbLink} />
          <Payment price={unitData.price} />
          <SocialLinks socialLinks={socialLinks} />
          <Chatbot />
          <Directions address={unitData.address} />
          <EmailCollection />
          <PromoCode promoCode={promoCode} validDays={validDays} />
        </div>
      );
    };

    export default App;
