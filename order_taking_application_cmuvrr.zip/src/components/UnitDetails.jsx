import React from 'react';

    const UnitDetails = ({ unitData }) => {
      return (
        <div className="unit-details">
          <h2>About This Unit</h2>
          <p>{unitData.description}</p>
          <h3>Amenities</h3>
          <ul>
            {unitData.amenities.map((amenity, index) => (
              <li key={index}>{amenity}</li>
            ))}
          </ul>
        </div>
      );
    };

    export default UnitDetails;
