import React from 'react';

    const SocialLinks = ({ socialLinks }) => {
      return (
        <div className="social-links">
          <h2>Connect With Us</h2>
          <a href={socialLinks.instagram} target="_blank" rel="noopener noreferrer">
            Instagram
          </a>
          <a href={socialLinks.tiktok} target="_blank" rel="noopener noreferrer">
            TikTok
          </a>
          <a href={socialLinks.facebook} target="_blank" rel="noopener noreferrer">
            Facebook
          </a>
        </div>
      );
    };

    export default SocialLinks;
