import React, { useState } from 'react';

    const EmailCollection = () => {
      const [email, setEmail] = useState('');
      const [submittedEmail, setSubmittedEmail] = useState('');

      const handleSubmit = (e) => {
        e.preventDefault();
        setSubmittedEmail(email);
        setEmail('');
      };

      return (
        <div className="email-collection-container">
          <h2>Stay Updated</h2>
          <p>Sign up for exclusive deals and promotions!</p>
          <form onSubmit={handleSubmit} className="email-form">
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <button type="submit">Subscribe</button>
          </form>
          {submittedEmail && (
            <p className="submitted-email">Thank you! You have subscribed with: {submittedEmail}</p>
          )}
        </div>
      );
    };

    export default EmailCollection;
