import React, { useState } from 'react';

    const Chatbot = () => {
      const [messages, setMessages] = useState([]);
      const [input, setInput] = useState('');

      const responses = {
        'hello': 'Welcome to Naya Waterfront! How can I help you plan your luxurious getaway?',
        'availability': 'You can check our real-time availability and book directly through our Airbnb listing: [link to Airbnb]',
        'price': 'Our current price is RM 750 per night. Be sure to check for any available discounts!',
        'amenities': 'Naya Waterfront offers a gourmet kitchen, ocean view balcony, infinity pool access, a karaoke system, and of course, free WiFi!',
        'location': 'We are located at No 1, Jalan Impian Putra 10, Taman Impian Putra, 71000 Port Dickson, Negeri Sembilan. You can find directions on our page.',
        'promo code': 'Use promo code BEACH20 on Saturdays and Sundays for an extra discount!',
        'discounts': 'We offer special discounts on select days. Check our promo code section for more details!',
        'contact': 'For any further inquiries, please contact us through our social media channels or our Airbnb listing.',
        'how many bedrooms': 'Naya Waterfront has 4 bedrooms',
        'is there parking': 'Yes, there is free parking on premises',
        'is breakfast provided': 'Breakfast is not provided',
        'can i bring pets': 'Pets are not allowed',
        'what time is check in': 'Check in is at 3PM',
        'what time is check out': 'Check out is at 12PM',
        'is there a bbq': 'There is no BBQ',
        'is there a pool': 'Yes, there is an infinity pool',
        'is there a karaoke system': 'Yes, there is a karaoke system',
        'is there a kitchen': 'Yes, there is a gourmet kitchen',
        'is there a balcony': 'Yes, there is an ocean view balcony',
        'is there wifi': 'Yes, there is free wifi',
        'is there tv': 'Yes, there is a TV',
        'is there air conditioning': 'Yes, there is air conditioning',
        'is there a washing machine': 'There is no washing machine',
        'is there a dryer': 'There is no dryer',
        'is there a dishwasher': 'There is no dishwasher',
        'is there a microwave': 'Yes, there is a microwave',
        'is there a refrigerator': 'Yes, there is a refrigerator',
        'is there a stove': 'Yes, there is a stove',
        'is there a oven': 'There is no oven',
        'is there a coffee maker': 'There is no coffee maker',
        'is there a toaster': 'There is no toaster',
        'is there a blender': 'There is no blender',
        'is there a rice cooker': 'There is no rice cooker',
        'is there a water dispenser': 'There is no water dispenser',
        'is there a hot water': 'Yes, there is hot water',
        'is there a shower': 'Yes, there is a shower',
        'is there a wc': 'Yes, there is a WC',
        'is there a basin': 'Yes, there is a basin',
        'is there a wall mirror': 'Yes, there is a wall mirror',
        'is there hand wash': 'Yes, there is hand wash',
        'is there shampoo': 'Yes, there is shampoo',
        'is there shower gel': 'Yes, there is shower gel',
        'is there toilet roll': 'Yes, there is toilet roll',
        'is there a dining table': 'Yes, there is a dining table',
        'is there a sofa': 'Yes, there is a sofa',
        'is there a coffee table': 'Yes, there is a coffee table',
        'is there an android box': 'Yes, there is an android box',
        'is there a queen bed': 'Yes, there are queen beds',
        'is there a bunk bed': 'Yes, there are bunk beds',
        'is there a floor mattress': 'Yes, there are floor mattresses',
        'is there a beach nearby': 'Yes, there is a beach nearby',
        'how far is the beach': 'The beach is 5-10 minutes drive away',
        'is there a convenience store nearby': 'Yes, there is a convenience store nearby',
        'is there a restaurant nearby': 'Yes, there is a restaurant nearby',
        'is there a shopping mall nearby': 'Yes, there is a shopping mall nearby',
        'is there a hospital nearby': 'Yes, there is a hospital nearby',
        'is there a police station nearby': 'Yes, there is a police station nearby',
        'is there a fire station nearby': 'Yes, there is a fire station nearby',
        'is there a bus station nearby': 'Yes, there is a bus station nearby',
        'is there a train station nearby': 'No, there is no train station nearby',
        'is there an airport nearby': 'Yes, there is an airport nearby',
        'is there a taxi stand nearby': 'Yes, there is a taxi stand nearby',
        'is there a car rental nearby': 'Yes, there is a car rental nearby',
        'is there a motorcycle rental nearby': 'Yes, there is a motorcycle rental nearby',
        'is there a bicycle rental nearby': 'Yes, there is a bicycle rental nearby',
        'is there a boat rental nearby': 'Yes, there is a boat rental nearby',
        'is there a fishing spot nearby': 'Yes, there is a fishing spot nearby',
        'is there a diving spot nearby': 'Yes, there is a diving spot nearby',
        'is there a snorkeling spot nearby': 'Yes, there is a snorkeling spot nearby',
        'is there a surfing spot nearby': 'Yes, there is a surfing spot nearby',
        'is there a windsurfing spot nearby': 'Yes, there is a windsurfing spot nearby',
        'is there a kitesurfing spot nearby': 'Yes, there is a kitesurfing spot nearby',
        'is there a parasailing spot nearby': 'Yes, there is a parasailing spot nearby',
        'is there a jet ski rental nearby': 'Yes, there is a jet ski rental nearby',
        'is there a banana boat rental nearby': 'Yes, there is a banana boat rental nearby',
        'is there a water ski rental nearby': 'Yes, there is a water ski rental nearby',
        'is there a wakeboard rental nearby': 'Yes, there is a wakeboard rental nearby',
        'is there a paddle board rental nearby': 'Yes, there is a paddle board rental nearby',
        'is there a kayak rental nearby': 'Yes, there is a kayak rental nearby',
        'is there a canoe rental nearby': 'Yes, there is a canoe rental nearby',
        'is there a sailboat rental nearby': 'Yes, there is a yacht rental nearby',
        'is there a yacht rental nearby': 'Yes, there is a cruise ship terminal nearby',
        'is there a cruise ship terminal nearby': 'Yes, there is a ferry terminal nearby',
        'is there a ferry terminal nearby': 'Yes, there is a bus to Kuala Lumpur',
      };

      const handleSubmit = (e) => {
        e.preventDefault();
        if (!input) return;

        const userMessage = { text: input, sender: 'user' };
        setMessages([...messages, userMessage]);

        const lowerInput = input.toLowerCase();
        let botResponseText = responses[lowerInput] || responses['default'];

        const botResponse = { text: botResponseText, sender: 'bot' };
        setTimeout(() => {
          setMessages([...messages, userMessage, botResponse]);
        }, 500);

        setInput('');
      };

      return (
        <div className="chatbot-container">
          <h2>Luxury Chat Assistance</h2>
          <div className="chatbot-messages">
            {messages.map((message, index) => (
              <div key={index} className={`chatbot-message ${message.sender}`}>
                {message.text}
              </div>
            ))}
          </div>
          <form onSubmit={handleSubmit} className="chatbot-input-form">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question..."
            />
            <button type="submit">Send</button>
          </form>
        </div>
      );
    };

    export default Chatbot;
