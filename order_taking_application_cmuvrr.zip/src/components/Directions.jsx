import React, { useState } from 'react';

    const Directions = ({ address }) => {
      const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}`;
      const wazeUrl = `https://waze.com/ul?q=${encodeURIComponent(address)}&navigate=yes`;
      const [showSave, setShowSave] = useState(false);

      const handleSaveClick = () => {
        setShowSave(true);
      };

      return (
        <div className="directions-container">
          <h2>Plan Your Route</h2>
          <a href={googleMapsUrl} target="_blank" rel="noopener noreferrer" className="directions-button">
            Google Maps
          </a>
          <a href={wazeUrl} target="_blank" rel="noopener noreferrer" className="directions-button">
            Waze
          </a>
          <button className="save-location-button" onClick={handleSaveClick}>
            Save Location
          </button>
          {showSave && (
            <textarea
              readOnly
              value={address}
              className="location-textarea"
              onClick={(e) => e.target.select()}
            />
          )}
        </div>
      );
    };

    export default Directions;
