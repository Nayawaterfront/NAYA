import React from 'react';

    const menuItems = [
      { id: 1, name: 'Burger', price: 5.99 },
      { id: 2, name: 'Pizza', price: 8.99 },
      { id: 3, name: 'Fries', price: 2.99 },
      { id: 4, name: 'Drink', price: 1.99 },
    ];

    const Menu = ({ addToCart }) => {
      return (
        <div className="menu-container">
          <h2>Menu</h2>
          <ul>
            {menuItems.map((item) => (
              <li key={item.id}>
                {item.name} - ${item.price}
                <button onClick={() => addToCart(item)}>Add to Cart</button>
              </li>
            ))}
          </ul>
        </div>
      );
    };

    export default Menu;
