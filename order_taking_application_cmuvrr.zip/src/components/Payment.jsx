import React from 'react';

    const Payment = ({ price }) => {
      const handlePayment = () => {
        alert('Payment processing would occur here for: RM ' + price);
        // In a real application, you would integrate with a payment gateway like Stripe or PayPal.
      };

      return (
        <div className="payment-container">
          <h2>Payment</h2>
          <p>Price: RM {price}</p>
          <button onClick={handlePayment} className="pay-button">Indulge and Pay Now</button>
        </div>
      );
    };

    export default Payment;
