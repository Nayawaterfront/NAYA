import React from 'react';

    const VideoGallery = ({ videoUrl, videoSource }) => {
      let videoId = '';
      let embedUrl = '';

      if (videoUrl) {
        if (videoSource === 'youtube') {
          videoId = videoUrl.split('v=')[1];
          const ampersandPosition = videoId.indexOf('&');
          if (ampersandPosition !== -1) {
            videoId = videoId.substring(0, ampersandPosition);
          }
          embedUrl = `https://www.youtube.com/embed/${videoId}`;
        } else if (videoSource === 'tiktok') {
          videoId = videoUrl.split('/video/')[1];
          embedUrl = `https://www.tiktok.com/embed/v/${videoId}`;
        } else {
          embedUrl = videoUrl; // Use the videoUrl directly if the source is unknown
        }
      }

      return (
        <div className="video-gallery-container">
          <h2>Naya Waterfront Video</h2>
          {embedUrl ? (
            <iframe
              width="560"
              height="315"
              src={embedUrl}
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <p>No video available.</p>
          )}
        </div>
      );
    };

    export default VideoGallery;
