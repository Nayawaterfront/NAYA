import React from 'react';

    const BookingInfo = ({ price, originalPrice, airbnbLink }) => {
      return (
        <div className="booking-info">
          <h2>Book Now</h2>
          <p className="price">
            Price per night: RM {price}
            {originalPrice && originalPrice > price && (
              <span className="discount-flash"> Discounted!</span>
            )}
          </p>
          {originalPrice && originalPrice > price && (
            <p className="original-price">Original Price: RM {originalPrice}</p>
          )}
          <a href={airbnbLink} target="_blank" rel="noopener noreferrer" className="book-button">
            Book Your Luxurious Stay
          </a>
        </div>
      );
    };

    export default BookingInfo;
