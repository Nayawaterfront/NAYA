import React from 'react';

    const PromoCode = ({ promoCode, validDays }) => {
      const today = new Date();
      const dayOfWeek = today.toLocaleDateString('en-US', { weekday: 'long' });
      const isPromoActive = validDays.includes(dayOfWeek);

      return (
        <div className="promo-code-container">
          {isPromoActive ? (
            <>
              <h2>Exclusive Offer!</h2>
              <p>Use promo code <span className="promo-code">{promoCode}</span> for an extra discount today!</p>
            </>
          ) : (
            <p>Check back later for exclusive promo codes!</p>
          )}
        </div>
      );
    };

    export default PromoCode;
