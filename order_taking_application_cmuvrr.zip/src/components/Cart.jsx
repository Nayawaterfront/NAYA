import React from 'react';

    const Cart = ({ cart, removeFromCart }) => {
      const calculateTotal = () => {
        return cart.reduce((total, item) => total + item.price, 0).toFixed(2);
      };

      return (
        <div className="cart-container">
          <h2>Cart</h2>
          {cart.length === 0 ? (
            <p>Your cart is empty.</p>
          ) : (
            <ul>
              {cart.map((item, index) => (
                <li key={index}>
                  {item.name} - ${item.price}
                  <button onClick={() => removeFromCart(index)}>Remove</button>
                </li>
              ))}
            </ul>
          )}
          <p>Total: ${calculateTotal()}</p>
        </div>
      );
    };

    export default Cart;
